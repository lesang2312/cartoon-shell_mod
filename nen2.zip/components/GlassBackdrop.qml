import QtQuick
import Quickshell
import qs.services
import "glassNesting.js" as Nesting

// Nền kính của một cửa sổ/panel.
//  * Dựng lại hình nền (wallpaper) đúng vị trí phía sau panel trên màn hình.
//  * Vẽ chính panel bằng LiquidGlass.
//  * Cung cấp `texture` (đã có kính) cho các GlassFill lồng bên trong để chúng khúc xạ tiếp.
// Khi GlassService.enabled = false hoặc chưa có hình nền, `active` = false và item này ẩn hoàn toàn,
// panel quay về nền màu đặc ban đầu.
Item {
    id: root

    property real radius: 0
    property real topLeftRadius: radius
    property real topRightRadius: radius
    property real bottomLeftRadius: radius
    property real bottomRightRadius: radius

    property real tint: GlassService.panelTint
    property real frostAmount: GlassService.panelFrost
    property real rim: GlassService.rimStrength
    property color tintColor: GlassService.base
    property real bezelSize: Math.max(6, Math.min(34, Math.min(width, height) * GlassService.bezelRatio))

    readonly property bool isGlassBackdrop: true
    readonly property Item texture: glassTexture
    property int consumers: 0
    property int frame: 0
    property int nestLevel: 0
    readonly property real nest: Math.min(1, nestLevel * 0.5)

    property bool standalone: false
    property bool surfaceEnabled: true

    Component.onCompleted: {
        inheritedOwner = findInheritedOwner();
        nestLevel = (standalone || inheritedOwner !== null) ? 0 : Nesting.nestLevel(root, null, true);
        updateWallpaper();
    }

    // ---- Màn hình / cửa sổ chứa ----------------------------------------------------------
    property var screenOverride: null
    property Item inheritedOwner: null
    readonly property var inheritedScreen: inheritedOwner ? inheritedOwner.glassScreen : null

    function findInheritedOwner() {
        let e = root.parent;
        let d = 0;
        while (e && d < 64) {
            if (e.glassScreen !== undefined)
                return e;
            e = e.parent;
            d++;
        }
        return null;
    }

    onParentChanged: inheritedOwner = findInheritedOwner()
    readonly property var effectiveScreenOverride: screenOverride ? screenOverride : inheritedScreen

    readonly property var hostWindow: QsWindow.window
    readonly property var hostScreen: effectiveScreenOverride ? effectiveScreenOverride : (hostWindow ? hostWindow.screen : null)
    readonly property string screenName: hostScreen && hostScreen.name ? hostScreen.name : ""
    readonly property bool parentVisible: parent ? parent.visible : true

    readonly property bool wanted: surfaceEnabled && parentVisible && GlassService.enabled && width > 0 && height > 0 && hostScreen !== null && (hostWindow ? hostWindow.visible : true)
    readonly property bool active: wanted && wall.status === Image.Ready

    // ---- Hình nền ------------------------------------------------------------------------
    property string wallSource: ""
    property string videoPath: ""

    function toUrl(path) {
        if (!path)
            return "";
        const p = String(path);
        return p.indexOf("://") >= 0 ? p : "file://" + p;
    }

    function updateWallpaper() {
        if (!screenName)
            return;
        let path = "";
        try {
            path = WallpaperService.getWallpaper(screenName) || "";
        } catch (e) {
            path = "";
        }
        // Với video: dùng ảnh thumbnail trong cache làm nền kính.
        if (path && ThemeService.isVideoFile(path)) {
            videoPath = path;
            path = WallpaperService.getGlassThumbnailPath(path);
        } else {
            videoPath = "";
        }
        const url = toUrl(path);
        if (url !== wallSource)
            wallSource = url;
    }

    onScreenNameChanged: updateWallpaper()

    // Thanh bar được tạo trước khi WallpaperService nạp xong -> thử lại cho tới khi có đường dẫn hình nền.
    Timer {
        interval: 700
        repeat: true
        running: root.wanted && root.wallSource === ""
        onTriggered: root.updateWallpaper()
    }
    Connections {
        target: WallpaperService
        function onIsInitializedChanged() { root.updateWallpaper(); }
    }

    // Chẩn đoán: ghi log (kèm lý do) khi bật Liquid Glass mà kính vẫn không hiện.
    Timer {
        id: diag
        interval: 1500
        running: GlassService.enabled && root.parentVisible && root.width > 0
        repeat: false
        onTriggered: {
            if (!root.active) {
                const why = !root.hostScreen ? "khong tim thay man hinh (QsWindow.window null)"
                    : !root.wallSource ? "duong dan hinh nen rong (WallpaperService.getWallpaper tra ve rong)"
                    : wall.status === Image.Error ? "khong doc duoc hinh nen: " + root.wallSource
                    : "hinh nen chua Ready (status=" + wall.status + ") src=" + root.wallSource;
                console.warn("[LiquidGlass] KHONG ACTIVE o " + root.parent + ": " + why);
            } else {
                console.warn("[LiquidGlass] OK " + root.parent + " screen=" + root.screenName + " src=" + root.wallSource);
            }
        }
    }

    Connections {
        target: WallpaperService
        function onWallpaperChanged(name, path) {
            if (name === root.screenName)
                root.updateWallpaper();
        }
    }

    readonly property real screenWidth: hostScreen ? hostScreen.width : 1
    readonly property real screenHeight: hostScreen ? hostScreen.height : 1
    readonly property size textureSize: Qt.size(Math.max(1, Math.round(screenWidth / 2)), Math.max(1, Math.round(screenHeight / 2)))

    // ---- Hình học: vị trí màn hình so với item này ---------------------------------------
    property real imageX: 0
    property real imageY: 0
    property real imageScale: 1
    property real imageRotation: 0
    property rect validRect: Qt.rect(0, 0, 1, 1)
    property var geoSig: [NaN, 0, 0, 0, 0, 0, 0, 0]

    function refreshGeometry() {
        const w = root.hostWindow;
        const scr = root.hostScreen;
        if (!scr)
            return;
        let wx = 0;
        let wy = 0;
        if (w && w.anchors && !root.effectiveScreenOverride) {
            const a = w.anchors;
            const m = w.margins;
            if (a.left)
                wx = m.left;
            else if (a.right)
                wx = scr.width - w.width - m.right;
            else
                wx = (scr.width - w.width) / 2;
            if (a.top)
                wy = m.top;
            else if (a.bottom)
                wy = scr.height - w.height - m.bottom;
            else
                wy = (scr.height - w.height) / 2;
        }
        const p0 = root.mapFromItem(null, -wx, -wy);
        const px = root.mapFromItem(null, 1 - wx, -wy);
        const gs = root.geoSig;
        if (p0.x === gs[0] && p0.y === gs[1] && px.x === gs[2] && px.y === gs[3] && scr.width === gs[4] && scr.height === gs[5] && root.width === gs[6] && root.height === gs[7])
            return;
        gs[0] = p0.x;
        gs[1] = p0.y;
        gs[2] = px.x;
        gs[3] = px.y;
        gs[4] = scr.width;
        gs[5] = scr.height;
        gs[6] = root.width;
        gs[7] = root.height;
        const dx = px.x - p0.x;
        const dy = px.y - p0.y;
        const len = Math.sqrt(dx * dx + dy * dy);
        if (!isFinite(len) || len <= 0)
            return;
        root.imageX = p0.x;
        root.imageY = p0.y;
        root.imageScale = len;
        root.imageRotation = Math.atan2(dy, dx) * 180 / Math.PI;
        const p1 = root.mapFromItem(null, scr.width - wx, scr.height - wy);
        const iw = Math.max(1, root.width);
        const ih = Math.max(1, root.height);
        const x0 = Math.max(0, Math.min(1, Math.min(p0.x, p1.x) / iw));
        const y0 = Math.max(0, Math.min(1, Math.min(p0.y, p1.y) / ih));
        const x1 = Math.max(x0, Math.min(1, Math.max(p0.x, p1.x) / iw));
        const y1 = Math.max(y0, Math.min(1, Math.max(p0.y, p1.y) / ih));
        if (x0 !== root.validRect.x || y0 !== root.validRect.y || x1 - x0 !== root.validRect.width || y1 - y0 !== root.validRect.height)
            root.validRect = Qt.rect(x0, y0, x1 - x0, y1 - y0);
    }

    FrameAnimation {
        running: root.wanted
        onTriggered: {
            root.refreshGeometry();
            if (root.consumers > 0)
                root.frame++;
        }
    }

    onWantedChanged: {
        if (wanted) {
            updateWallpaper();
            refreshGeometry();
        }
    }

    // ---- Cập nhật texture khi có thay đổi --------------------------------------------------
    function refreshTexture() {
        if (root.active && root.consumers > 0)
            glassTexture.scheduleUpdate();
    }

    onImageXChanged: refreshTexture()
    onImageYChanged: refreshTexture()
    onImageScaleChanged: refreshTexture()
    onImageRotationChanged: refreshTexture()
    onWidthChanged: refreshTexture()
    onHeightChanged: refreshTexture()
    onConsumersChanged: refreshTexture()
    onActiveChanged: refreshTexture()
    onTintChanged: refreshTexture()
    onFrostAmountChanged: refreshTexture()
    onTintColorChanged: refreshTexture()
    onValidRectChanged: refreshTexture()

    visible: active
    clip: false

    // Lớp hình nền (nguồn cho shader)
    Item {
        id: content
        anchors.fill: parent
        visible: false
        layer.enabled: root.active
        layer.mipmap: true
        layer.smooth: true

        Image {
            id: wall
            x: root.imageX
            y: root.imageY
            width: root.screenWidth
            height: root.screenHeight
            scale: root.imageScale
            rotation: root.imageRotation
            transformOrigin: Item.TopLeft
            source: root.wanted ? root.wallSource : ""
            fillMode: Image.PreserveAspectCrop
            asynchronous: true
            cache: true
            smooth: true
            mipmap: true
            sourceSize: root.textureSize
            onStatusChanged: {
                root.refreshTexture();
                // Thumbnail của video chưa có -> tạo bằng ffmpeg rồi nạp lại.
                if (status === Image.Error && root.videoPath !== "") {
                    const vp = root.videoPath;
                    WallpaperService.ensureGlassThumbnail(vp, function (thumb) {
                        if (root.videoPath === vp) {
                            root.wallSource = "";
                            root.updateWallpaper();
                        }
                    });
                }
            }
        }
    }

    // Chính panel được vẽ bằng kính
    Item {
        id: rendered
        anchors.fill: parent

        GlassFallback {
            anchors.fill: parent
            visible: root.active && !GlassService.customShader
            src: root.active ? content : null
            topLeftRadius: root.topLeftRadius
            topRightRadius: root.topRightRadius
            bottomLeftRadius: root.bottomLeftRadius
            bottomRightRadius: root.bottomRightRadius
            bezel: root.bezelSize
            nest: root.nest
        }

        LiquidGlass {
            id: glassEffect
            anchors.fill: parent
            visible: root.active && GlassService.customShader
            src: root.active ? content : null
            topLeftRadius: root.topLeftRadius
            topRightRadius: root.topRightRadius
            bottomLeftRadius: root.bottomLeftRadius
            bottomRightRadius: root.bottomRightRadius
            tintColor: root.tintColor
            tintAmount: root.tint * (1 - 0.5 * root.nest)
            frost: root.frostAmount * (1 - 0.5 * root.nest)
            rim: root.rim * (1 - 0.35 * root.nest)
            nest: root.nest
            bezel: root.bezelSize
            thickness: root.bezelSize * GlassService.thicknessScale
            dispersion: GlassService.dispersion
            saturation: GlassService.saturation
            validRect: root.validRect
            clear: root.nestLevel >= 1 ? 1 : 0
            cursorPos: Qt.point(root.cursorX, root.cursorY)
            hover: root.hoverAmount
        }
    }

    // Texture (đã có kính) cho GlassFill lồng bên trong
    ShaderEffectSource {
        id: glassTexture
        anchors.fill: parent
        sourceItem: root.active ? rendered : null
        live: false
        mipmap: true
        visible: false
        smooth: true
        format: ShaderEffectSource.RGBA8
    }

    // ---- Con trỏ ---------------------------------------------------------------------------
    HoverHandler {
        id: pointer
        enabled: root.active
    }

    property real hoverAmount: pointer.hovered ? 1.0 : 0.0
    Behavior on hoverAmount {
        NumberAnimation {
            duration: 260
            easing.type: Easing.OutCubic
        }
    }

    property real cursorX: width / 2
    property real cursorY: height / 2
    Behavior on cursorX {
        NumberAnimation {
            duration: 120
            easing.type: Easing.OutCubic
        }
    }
    Behavior on cursorY {
        NumberAnimation {
            duration: 120
            easing.type: Easing.OutCubic
        }
    }

    Connections {
        target: pointer
        function onPointChanged() {
            if (pointer.hovered) {
                root.cursorX = pointer.point.position.x;
                root.cursorY = pointer.point.position.y;
            }
        }
    }
}
