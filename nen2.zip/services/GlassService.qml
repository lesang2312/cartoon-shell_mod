pragma Singleton

import QtQuick
import Quickshell
import qs.commons
import qs.services

// Trạng thái toàn cục của hiệu ứng Liquid Glass.
// Công tắc được lưu trong Settings.appearance.liquidGlass (settings.json của shell).
Singleton {
    id: root

    // ---- Công tắc chính (nút trong Settings -> Theme) -------------------------------------
    readonly property bool enabled: Settings.appearance.liquidGlass
    readonly property bool liquidGlass: enabled

    function setEnabled(value) {
        Settings.appearance.liquidGlass = value;
    }

    function toggle() {
        setEnabled(!enabled);
    }

    // ---- Thông số dùng chung ---------------------------------------------------------------
    // Màu nền kính theo theme hiện tại (luôn opaque; shader tự điều khiển độ đậm).
    readonly property color base: {
        const t = ThemeService.theme;
        const c = Qt.color((t && t.primary && t.primary.background) ? t.primary.background : "#13140d");
        return Qt.rgba(c.r, c.g, c.b, 1);
    }
    // Độ đậm lớp phủ màu của panel chính (0 = trong suốt, 1 = đặc).
    property real panelTint: 0.6
    // true = dùng shader liquid_glass.frag.qsb (phải biên dịch đúng cho máy bạn).
    // false = dùng GlassFallback (MultiEffect có sẵn của Qt, không cần shader tùy chỉnh).
    property bool customShader: false
    // Độ đen của nền sau kính (0..1) — giúp chữ luôn dễ đọc.
    property real blackBacking: 0.0
    // Mức phóng to hình nền ở viền kính (>1 = khúc xạ sâu hơn).
    property real refractionDepth: 1.45

    // ---- Khúc xạ & ánh sáng (kiểu macOS / Serpantinum) ------------------------------------
    // Độ rộng vùng viền khúc xạ so với cạnh ngắn của panel.
    property real bezelRatio: 0.2
    // Độ dày kính = bezel * thicknessScale (lớn hơn -> hình nền bị bẻ cong mạnh hơn ở mép).
    property real thicknessScale: 1.9
    // Tán sắc (viền cầu vồng ở mép kính).
    property real dispersion: 0.2
    // Độ sáng của viền phản chiếu (specular rim).
    property real rimStrength: 0.95
    // Độ bão hòa màu của hình nền sau kính.
    property real saturation: 1.35

    // Độ mờ (frost) của panel chính.
    property real panelFrost: 2.4

    readonly property url shaderUrl: "file://" + Quickshell.shellDir + "/shaders/qsb/liquid_glass.frag.qsb"
}
