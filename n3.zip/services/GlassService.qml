pragma Singleton

import QtQuick
import Quickshell
import qs.commons
import qs.services

// Trạng thái toàn cục của hiệu ứng Liquid Glass.
// Công tắc được lưu trong Settings.appearance.liquidGlass (settings.json của shell).
Singleton {
    id: root

    // ---- Công tắc chính (nút trong Settings -> Theme) -------------------------------------
    readonly property bool enabled: Settings.appearance.liquidGlass
    readonly property bool liquidGlass: enabled

    function setEnabled(value) {
        Settings.appearance.liquidGlass = value;
    }

    function toggle() {
        setEnabled(!enabled);
    }

    // ---- Thông số dùng chung ---------------------------------------------------------------
    // Màu nền kính theo theme hiện tại (luôn opaque; shader tự điều khiển độ đậm).
    readonly property color base: {
        const t = ThemeService.theme;
        const c = Qt.color((t && t.primary && t.primary.background) ? t.primary.background : "#13140d");
        return Qt.rgba(c.r, c.g, c.b, 1);
    }
    // Lớp màu nền rất nhẹ: giữ màu wallpaper và độ xuyên sáng là ưu tiên.
    property real panelTint: 0.024
    // Bật shader kính lỏng chất lượng cao (QSB đã được đóng gói trong shaders/qsb).
    // Có thể tắt để dùng GlassFallback nếu GPU/driver không tương thích.
    property bool customShader: true
    // Chỉ dùng cho fallback khi shader không khả dụng; không phủ đen bề mặt.
    property real blackBacking: 2
    // Chiều sâu viền cho fallback: vừa đủ tạo khúc xạ, tránh méo ảnh quá mạnh.
    property real refractionDepth: 3
    // IOR gần thủy tinh quang học thông dụng, giảm méo quá mức ở cạnh.
    property real ior: 2

    // ---- Khúc xạ & ánh sáng (kiểu macOS / Serpantinum) ------------------------------------
    // Bevel đủ sâu để nhìn thấy mép thấu kính trên panel lớn lẫn các pill nhỏ.
    property real bezelRatio: 1
    // Tăng độ dày quang học; phần lớn độ lệch tia xuất hiện ở dải bevel, không làm méo cả mặt.
    property real thicknessScale: 5
    // Tán sắc vừa phải: thấy ánh RGB ở mép nhưng không biến thành viền neon.
    property real dispersion: 2
    // Viền phản chiếu mảnh, giữ độ sáng cân đối cho chữ.
    property real rimStrength: 1
    property real saturation: 2.5

    // Mặt kính gần như trong; frost nhẹ để chống cảm giác phẳng mà vẫn đọc chữ rõ.
    property real panelFrost: 2

    // 72% mỗi chiều giữ hình nền đủ sắc nét cho độ lệch tia mới; lượng pixel khoảng 52% full-res.
    // Có thể giảm về 0.55 trên GPU yếu; chỉ tăng lên 0.80 nếu còn dư GPU.
    property real textureScale: 2

    readonly property url shaderUrl: "file://" + Quickshell.shellDir + "/shaders/qsb/liquid_glass.frag.qsb"
}
