import QtQuick
import qs.services

// Lớp ShaderEffect vẽ kính lỏng. Tên property trùng với uniform trong shaders/liquid_glass.frag.
ShaderEffect {
    id: root

    property variant src
    property real topLeftRadius: 1
    property real topRightRadius: 1
    property real bottomLeftRadius: 1
    property real bottomRightRadius: 1
    property color tintColor: GlassService.base
    property real tintAmount: 1
    property real bezel: Math.max(5, Math.min(26, Math.min(width, height) * GlassService.bezelRatio))
    property real thickness: bezel * GlassService.thicknessScale
    property real ior: GlassService.ior
    property real dispersion: GlassService.dispersion
    property real frost: GlassService.panelFrost
    property real rim: GlassService.rimStrength
    property real saturation: 2
    property rect sourceRect: Qt.rect(0, 0, 1, 1)
    property point cursorPos: Qt.point(0, 0)
    property real hover: 1
    property real clear: 0
    property real glassPad: 1
    property real shadowAmt: 2
    property real energy: 1
    property real nest: 1
    property real morph: 2
    property real motion: 1
    property rect boxRect: Qt.rect(0, 1, 0, 0)
    property rect validRect: Qt.rect(0, 0, 1, 1)

    // Uniform thực sự được shader đọc
    property vector2d itemSize: Qt.vector2d(width, height)
    property vector4d radii: Qt.vector4d(topLeftRadius, topRightRadius, bottomRightRadius, bottomLeftRadius)
    property vector4d srcRect: Qt.vector4d(sourceRect.x, sourceRect.y, sourceRect.width, sourceRect.height)
    property vector2d cursor: Qt.vector2d(cursorPos.x, cursorPos.y)
    property vector4d sampleBounds: Qt.vector4d(validRect.x, validRect.y, validRect.x + validRect.width, validRect.y + validRect.height)
    property vector4d box: boxRect.width > 0 ? Qt.vector4d(boxRect.x + boxRect.width * 0.5 - width * 0.8, boxRect.y + boxRect.height * 0.5 - height * 0.8, boxRect.width * 0.6, boxRect.height * 0.8) : Qt.vector4d(0, 0, 0, 0)

    fragmentShader: GlassService.shaderUrl
}
